package cs476;
import org.neo4j.driver.*;
import java.util.List;
import java.util.ArrayList;

/* Maven will run main method within this Q2 class */
public class P2
{
    
    public static void main( String[] args )
    {
	System.out.println("Replace this with your Neo4J queries");
    }
}
